# 🚀 How to Upload Mockup to GitHub and Get Share Link

## Method 1: GitHub Web Interface (Easiest - No Git Knowledge Needed)

### Step 1: Create GitHub Account
1. Go to https://github.com
2. Click "Sign up"
3. Follow the registration steps
4. Verify your email

### Step 2: Create New Repository
1. Click the **"+"** icon in top-right corner
2. Select **"New repository"**
3. Fill in:
   - **Repository name**: `dont-trust-it-mockup` (or any name you like)
   - **Description**: "Interactive mockup for Don't Trust It: Ghost Village game"
   - **Public** (must be public for free GitHub Pages)
   - ✅ Check "Add a README file"
4. Click **"Create repository"**

### Step 3: Upload HTML File
1. In your new repo, click **"Add file"** → **"Upload files"**
2. Drag `share_mockup.html` into the upload area
   - OR click "choose your files" and select it
3. **IMPORTANT**: Rename file to `index.html` in the file list
   - GitHub Pages needs `index.html` as the main file
4. Add commit message: "Add mockup"
5. Click **"Commit changes"**

### Step 4: Enable GitHub Pages
1. Go to your repo **Settings** (gear icon at top)
2. Scroll down left sidebar to **"Pages"**
3. Under "Build and deployment":
   - **Source**: Deploy from a branch
   - **Branch**: Select `main` (or `master`)
   - **Folder**: Select `/ (root)`
4. Click **"Save"**
5. Wait 1-2 minutes for deployment

### Step 5: Get Your Share Link
Your site will be live at:
```
https://YOUR-USERNAME.github.io/dont-trust-it-mockup
```

Example:
```
https://johndoe.github.io/dont-trust-it-mockup
```

---

## Method 2: Using Git Command Line (For Developers)

### Prerequisites
```bash
# Install Git
# macOS: Already installed or use Homebrew
brew install git

# Windows: Download from https://git-scm.com/

# Linux:
sudo apt-get install git
```

### Step-by-Step Commands

```bash
# 1. Navigate to your mockup folder
cd /path/to/your/folder

# 2. Initialize Git repo
git init

# 3. Rename mockup file to index.html
mv share_mockup.html index.html

# 4. Add file to Git
git add index.html

# 5. Commit
git commit -m "Add interactive game mockup"

# 6. Create main branch (if needed)
git branch -M main

# 7. Connect to GitHub
# First, create empty repo on GitHub (don't add README)
git remote add origin https://github.com/YOUR-USERNAME/dont-trust-it-mockup.git

# 8. Push to GitHub
git push -u origin main

# 9. Enable GitHub Pages (via web interface - see Method 1 Step 4)
```

---

## Method 3: GitHub Desktop (Visual Interface)

### Step 1: Install GitHub Desktop
- Download: https://desktop.github.com/
- Install and sign in with your GitHub account

### Step 2: Create Repository
1. Click **"File"** → **"New Repository"**
2. Fill in:
   - Name: `dont-trust-it-mockup`
   - Local path: Choose folder location
   - ✅ Initialize with README
3. Click **"Create Repository"**

### Step 3: Add Mockup File
1. Copy `share_mockup.html` to the repository folder
2. Rename it to `index.html`
3. GitHub Desktop will show the new file
4. Add commit message: "Add interactive mockup"
5. Click **"Commit to main"**

### Step 4: Publish to GitHub
1. Click **"Publish repository"**
2. Uncheck "Keep this code private" (must be public for free Pages)
3. Click **"Publish repository"**

### Step 5: Enable Pages
- Follow Method 1, Step 4 (web interface)

---

## 📝 Quick Reference

### File Names
```
❌ share_mockup.html  → Won't work
✅ index.html          → Works on GitHub Pages
```

### Your Share Link Format
```
https://[YOUR-USERNAME].github.io/[REPO-NAME]

Examples:
https://johndoe.github.io/dont-trust-it-mockup
https://marynguyen.github.io/game-mockup
https://devstudio.github.io/ghost-village
```

---

## 🎯 Verification Steps

After deploying, check if it works:

1. **Open your link** in browser
2. **Test on mobile** (should be responsive)
3. **Try share buttons** (Twitter, Facebook, etc.)
4. **Drag joystick** (should be interactive)

If page shows 404:
- Wait 2-3 minutes (deployment takes time)
- Check file is named `index.html` (not `share_mockup.html`)
- Verify repo is **Public**
- Check GitHub Pages is enabled in Settings

---

## 🔧 Troubleshooting

### Issue: 404 Error
**Solution:**
- Ensure file is named `index.html`
- Wait 2-3 minutes after enabling Pages
- Check repo is Public
- Verify Pages is enabled in Settings → Pages

### Issue: Styles Not Loading
**Solution:**
- Fonts load from Google CDN (need internet)
- Check browser console for errors (F12)
- Clear browser cache (Ctrl+Shift+R)

### Issue: Can't Enable Pages
**Solution:**
- Repo must be Public (not Private)
- Free GitHub accounts get unlimited public Pages
- Make sure you're in Settings → Pages section

### Issue: Share Buttons Don't Work
**Solution:**
- Buttons use JavaScript to open share dialogs
- Test in different browser
- Some ad blockers may block social share popups

---

## 🎨 Customization After Upload

### Update GitHub Link
Edit line ~1166 in the HTML:
```html
<!-- Change this: -->
<a href="https://github.com/yourusername/dont-trust-it-ghost-village" 

<!-- To your actual repo: -->
<a href="https://github.com/YOUR-USERNAME/YOUR-REPO-NAME"
```

### Update Metadata
Edit lines 8-11:
```html
<meta property="og:title" content="Your Custom Title">
<meta property="og:description" content="Your Description">
```

### To Update After Publishing
1. Edit `index.html` on GitHub (click pencil icon)
2. Make changes
3. Commit changes
4. Wait 1-2 minutes for redeployment
5. Hard refresh browser (Ctrl+Shift+R)

---

## 🌟 Pro Tips

### Custom Domain (Optional)
You can use your own domain:
1. Buy domain (e.g., Namecheap, Google Domains)
2. Go to repo Settings → Pages
3. Add custom domain
4. Update DNS records

### Analytics (Optional)
Add Google Analytics:
```html
<!-- Add before </head> -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### SEO Enhancement
Add to `<head>`:
```html
<meta name="keywords" content="game, horror, social deduction, flutter, flame engine">
<meta name="author" content="Your Name">
<link rel="canonical" href="https://yourusername.github.io/dont-trust-it-mockup">
```

---

## ✅ Checklist

Before sharing your link:

- [ ] Mockup is live at your GitHub Pages URL
- [ ] Page loads correctly on desktop
- [ ] Page works on mobile
- [ ] Share buttons work
- [ ] Joystick is draggable
- [ ] Animations are smooth
- [ ] All images/icons display
- [ ] No console errors (F12)

---

## 📤 After Upload - Share Your Link!

### Social Media Templates

**Twitter:**
```
🎮 Check out my interactive game mockup!

"Don't Trust It: Ghost Village" - a horror-comedy social deduction game built with Flutter + Flame Engine

👉 https://YOUR-USERNAME.github.io/dont-trust-it-mockup

Try dragging the joystick! 👻

#FlutterDev #GameDev #IndieGame
```

**LinkedIn:**
```
Excited to share the interactive mockup for my latest project: Don't Trust It: Ghost Village!

A mobile social deduction game featuring:
• Smart AI with behavior trees
• Fog of war system
• Vietnamese-inspired aesthetics
• 100% Flutter + Flame Engine

Try it out: https://YOUR-USERNAME.github.io/dont-trust-it-mockup

#Flutter #GameDevelopment #MobileDev
```

**Reddit (r/FlutterDev):**
```
[Show & Tell] Interactive mockup of my Flutter game

I built a complete social deduction game called "Don't Trust It: Ghost Village"

Live mockup: https://YOUR-USERNAME.github.io/dont-trust-it-mockup
GitHub: https://github.com/YOUR-USERNAME/dont-trust-it-mockup

Features:
- Drag the joystick to test controls
- 5 AI bots with state machines
- Fog of war rendering
- Task system
- Mobile-optimized

Feedback appreciated! 🙏
```

---

## 📊 Track Your Views

### GitHub Insights
- Go to your repo → **Insights** → **Traffic**
- See page views and unique visitors
- Available after 14 days

### Free Analytics
1. **Google Analytics** (most popular)
2. **Plausible** (privacy-friendly)
3. **Simple Analytics** (minimalist)
4. **GoatCounter** (free & open source)

---

## 🎉 Success!

Once deployed, you'll have:
- ✅ Permanent share link
- ✅ Professional portfolio piece
- ✅ Interactive demo
- ✅ Social media ready
- ✅ Mobile friendly
- ✅ Fast loading
- ✅ Free hosting forever

**Estimated time: 5-10 minutes from start to live link!**

---

## 📞 Need Help?

If you get stuck:
1. GitHub Docs: https://docs.github.com/en/pages
2. GitHub Community: https://github.community/
3. Stack Overflow: Search "github pages" tag

---

**Now go upload and get your link! 🚀👻**
